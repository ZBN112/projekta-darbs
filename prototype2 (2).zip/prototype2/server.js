const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(cors());

const dbPath = 'C:/Users/ZBNinzja/Music/reactiontime.db';
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS reaction_times (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      reaction_time INTEGER NOT NULL,
      age INTEGER
    )
  `);

  console.log('Database setup completed.');
});

app.post('/record-reaction-time', (req, res) => {
  try {
    const { name, reactionTime, age } = req.body;
    console.log('Received data:', { name, reactionTime, age });

    if (!name || isNaN(reactionTime) || isNaN(age)) {
      console.log('Invalid data format');
      return res.status(400).json({ error: 'Invalid data format' });
    }

    db.run('INSERT INTO reaction_times (name, reaction_time, age) VALUES (?, ?, ?)', [name, reactionTime, age], function (err) {
      if (err) {
        console.error('Error inserting data into the database:', err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }

      console.log(`Inserted record with ID: ${this.lastID}`);
      return res.json({ success: true });
    });
  } catch (error) {
    console.error('Error in /record-reaction-time route:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

process.on('exit', () => {
  db.close((err) => {
    if (err) {
      return console.error(err.message);
    }
    console.log('Closed the database connection.');
  });
});